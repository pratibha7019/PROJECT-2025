const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, "Product name is required"],
        },
       
        quantity: {
            type: Number,
            required: true,
            default: 0,
        },

        image: {
            type: String,
            required: false,
        }
    },
    {
        : true,
    }
);

const Protimestampsduct = mongoose.model("Product", ProductSchema);

module.exports = Product;