const express = require("express");
const Product = require("../models/product.model.js");
const routes = express.Router();
const {getProducts, getProduct,createProduct,updateProduct,deleteProduct} = require("../controllers/product.controller.js");

routes.get("/", getProducts);
routes.get("/:id", getProduct);
routes.post("/", createProduct);
routes.put("/:id", updateProduct);
routes.delete("/:id", deleteProduct);

module.exports = routes;
